<!DOCTYPE html>
<html>
    <body>
        <h1>first php</h1>
        <?php
        echo"hello php";
        ?>
        
    </body>
</html>