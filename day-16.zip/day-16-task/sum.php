<!DOCTYPE html>
<html>
<body>

<?php
$x = 5;
$y = 4;
$c= $x + $y;
echo "sum is $c" ;
?>

</body>
</html>
s